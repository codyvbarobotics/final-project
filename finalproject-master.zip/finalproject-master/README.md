# finalproject
This is a joint project 
ideas:
1.led light bulbs that turns on when the alarm goes off.
2.grapling hook with lights.
3.
